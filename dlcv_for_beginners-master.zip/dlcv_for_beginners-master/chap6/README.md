## 第6章示例代码
包含并行数据增加工具和物体框标注小工具。  
参考本书第6章，或在线版本：
https://zhuanlan.zhihu.com/p/24425116

书中的数据增加小工具使用的是手动均衡，使用Python进程池的自动均衡版本，可以参考run_augmentation_pool_map.py
