## 第5章示例代码

参考本书第5章，或在线版本：
https://zhuanlan.zhihu.com/p/24162430  
https://zhuanlan.zhihu.com/p/24309547 

