# 和本书内容无关，知识点可能有关的一些杂乱内容

## [基于Caffe的对抗样本的生成](https://github.com/frombeijingwithlove/dlcv_for_beginners/blob/master/random_bonus/adversarial_example_caffe)
## [GAN和Conditional GAN生成二维样本](https://github.com/frombeijingwithlove/dlcv_for_beginners/tree/master/random_bonus/gan_n_cgan_2d_example)
## [用Yahoo!的Open NSFW给XX图片生成马赛克](https://github.com/frombeijingwithlove/dlcv_for_beginners/tree/master/random_bonus/generate_mosaic_for_porno_images)
## [基于PyTorch实现的U-Net](https://github.com/frombeijingwithlove/dlcv_for_beginners/tree/master/random_bonus/image-segmentation(updating))  
## [Caffe中的模型融合](https://github.com/frombeijingwithlove/dlcv_for_beginners/tree/master/random_bonus/multiple_models_fusion_caffe)

