#!/bin/sh
git clone https://github.com/yahoo/open_nsfw.git
