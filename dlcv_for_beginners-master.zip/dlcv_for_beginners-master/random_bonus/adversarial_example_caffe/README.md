## Generating Adversarial Examples
Blog: 
[用Caffe生成对抗样本](https://zhuanlan.zhihu.com/p/26122612)

## step 1
> ./download-squeezenet-v1.0-weights.sh  

to download weights for SqueezeNet v1.0.

## step 2

> python adversarial_example_demo.py little_white_dog.jpg  

to check the demo results.