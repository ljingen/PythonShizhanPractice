## 第十章 迁移学习和模型微调

从搜索引擎上下载关键词对应的图片，并利用模型微调进行训练，以及最后的模型评估，分析和可视化。

具体用法参考本书第十章内容。

书中例子对应的预训练模型可以在下面地址下载：  
https://github.com/frombeijingwithlove/dlcv_book_pretrained_caffe_models/blob/master/food_resnet-10_iter_10000.caffemodel  
或  
http://pan.baidu.com/s/1jHRLsLw