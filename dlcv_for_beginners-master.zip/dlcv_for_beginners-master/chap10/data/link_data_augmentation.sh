ln -s ../../chap6/data_augmentation/run_augmentation.py run_augmentation.py
ln -s ../../chap6/data_augmentation/image_augmentation.py image_augmentation.py

