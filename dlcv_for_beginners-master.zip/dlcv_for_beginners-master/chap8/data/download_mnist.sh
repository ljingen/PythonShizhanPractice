#!/bin/sh
# wget http://www.iro.umontreal.ca/~lisa/deep/data/mnist/mnist.pkl.gz
wget http://deeplearning.net/data/mnist/mnist.pkl.gz
